import type {StructureResolver,DefaultDocumentNodeResolver} from 'sanity/structure';
import {CogIcon,HomeIcon} from '@sanity/icons';
import {DraftPreview} from './preview';
export const singletonTypes=new Set(['siteSettings','homePage']);
export const structure:StructureResolver=S=>S.list().title('JDPI website').items([
  S.listItem().title('Site settings & donations').icon(CogIcon).child(S.document().schemaType('siteSettings').documentId('siteSettings')),
  S.listItem().title('Homepage & impact figures').icon(HomeIcon).child(S.document().schemaType('homePage').documentId('homePage')),
  S.divider(),
  S.documentTypeListItem('programme').title('Programmes'),S.documentTypeListItem('project').title('Projects'),
  S.documentTypeListItem('story').title('Stories & updates'),S.documentTypeListItem('report').title('Reports & publications'),S.documentTypeListItem('partner').title('Partners & donors'),
]);
export const defaultDocumentNode:DefaultDocumentNodeResolver=S=>S.document().views([S.view.form().title('Edit'),S.view.component(DraftPreview).title('Draft preview')]);
